$("document").ready(function(){

$("body").append("<h1>This is a heading</h1>");


});

